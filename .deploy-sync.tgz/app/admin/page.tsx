import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { AdminDashboardClient } from "@/components/admin/AdminDashboardClient";
import { ExportButton } from "@/components/admin/ExportButton";
import { AdminFilters } from "@/components/admin/AdminFilters";
import { YONALISH_LABELS, YOSH_GURUH_LABELS } from "@/lib/validations";
import { hasAdminSession } from "@/lib/admin-auth";

interface SearchParams {
  holat?: string;
  yoshGuruhi?: string;
  yonalish?: string;
  utmType?: string;
  smsStatus?: string;
  q?: string;
  page?: string;
  sortBy?: string;
  sortDir?: string;
}

const HOLAT_VALUES = ["KUTILMOQDA", "TASDIQLANDI", "RAD_ETILDI"] as const;
const YOSH_VALUES = ["YOSH_9_11", "YOSH_12_14", "YOSH_9_14"] as const;
const YONALISH_VALUES = ["MATEMATIKA", "TYPING"] as const;
const UTM_TYPE_VALUES = ["MAKTAB", "BANNER", "ORGANIK"] as const;
const SMS_STATUS_VALUES = ["PENDING", "SENT", "FAILED"] as const;
const PAGE_SIZE = 15;
const SORT_BY_VALUES = ["createdAt", "resultScore", "resultUpdatedAt", "resultStatus"] as const;
const SORT_DIR_VALUES = ["asc", "desc"] as const;

function getSanitizedSearchQuery(raw: string | undefined) {
  const value = (raw ?? "").trim();
  if (!value) return "";
  return value.slice(0, 80);
}

function parseEnum<T extends readonly string[]>(raw: string | undefined, values: T): T[number] | undefined {
  if (!raw) return undefined;
  return (values as readonly string[]).includes(raw) ? (raw as T[number]) : undefined;
}

function parsePage(raw: string | undefined) {
  const numeric = Number.parseInt(raw ?? "", 10);
  if (!Number.isFinite(numeric) || numeric < 1) return 1;
  return numeric;
}

export default async function AdminPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params = await searchParams;
  const holat = parseEnum(params.holat, HOLAT_VALUES);
  const yoshGuruhi = parseEnum(params.yoshGuruhi, YOSH_VALUES);
  const yonalish = parseEnum(params.yonalish, YONALISH_VALUES);
  const utmType = parseEnum(params.utmType, UTM_TYPE_VALUES);
  const smsStatus = parseEnum(params.smsStatus, SMS_STATUS_VALUES);
  const sortBy = parseEnum(params.sortBy, SORT_BY_VALUES) ?? "createdAt";
  const sortDir = parseEnum(params.sortDir, SORT_DIR_VALUES) ?? "desc";
  const orderBy: Prisma.RoyxatOrderByWithRelationInput[] =
    sortBy === "createdAt"
      ? [{ createdAt: sortDir }]
      : sortBy === "resultScore"
        ? [{ resultScore: { sort: sortDir, nulls: "last" } }, { createdAt: "desc" }]
        : sortBy === "resultUpdatedAt"
          ? [{ resultUpdatedAt: { sort: sortDir, nulls: "last" } }, { createdAt: "desc" }]
          : [{ resultStatus: { sort: sortDir, nulls: "last" } }, { createdAt: "desc" }];
  const searchQuery = getSanitizedSearchQuery(params.q);
  const requestedPage = parsePage(params.page);
  const store = await cookies();

  if (!hasAdminSession(store)) {
    redirect("/admin/login");
  }

  const where: Prisma.RoyxatWhereInput = {};
  if (holat) where.holat = holat;
  if (yoshGuruhi) where.yoshGuruhi = yoshGuruhi;
  if (yonalish) where.yonalish = yonalish;
  if (utmType) where.utmType = utmType;
  if (smsStatus) where.smsStatus = smsStatus;
  if (searchQuery) {
    where.OR = [
      { ism: { contains: searchQuery, mode: "insensitive" } },
      { familiya: { contains: searchQuery, mode: "insensitive" } },
      { participantId: { contains: searchQuery, mode: "insensitive" } },
    ];
  }

  let royxatlar: Array<{
    id: string;
    participantId: string | null;
    ism: string;
    familiya: string;
    otasiningIsmi: string;
    telefon: string;
    yonalish: string;
    yoshGuruhi: string;
    utmType: "MAKTAB" | "BANNER" | "ORGANIK";
    utmSource: string | null;
    utmMedium: string | null;
    utmCampaign: string | null;
    smsStatus: "PENDING" | "SENT" | "FAILED";
    smsSentAt: Date | null;
    smsError: string | null;
    smsMessageId: string | null;
    resultStatus: string | null;
    resultScore: number | null;
    resultNote: string | null;
    resultUpdatedAt: Date | null;
    holat: "KUTILMOQDA" | "TASDIQLANDI" | "RAD_ETILDI";
    createdAt: Date;
  }> = [];
  let totalCount = 0;
  let filteredCount = 0;
  let currentPage = requestedPage;
  let totalPages = 1;
  let holatMap: Record<string, number> = {};
  let yoshMap: Record<string, number> = {};
  let yonalishMap: Record<string, number> = {};

  const loadDashboardData = async (activeWhere: Prisma.RoyxatWhereInput) => {
    let dbFilteredCount = 0;
    let holatStats: Array<{ holat: string; _count: { _all: number } }> = [];
    let dbTotal = 0;
    try {
      [dbFilteredCount, holatStats, dbTotal] = await Promise.all([
        db.royxat.count({ where: activeWhere }),
        db.royxat.groupBy({ by: ["holat"], _count: { _all: true } }),
        db.royxat.count(),
      ]);
    } catch {
      return null;
    }

    let yoshStats: Array<{ yoshGuruhi: string; _count: { _all: number } }> = [];
    let yonalishStats: Array<{ yonalish: string; _count: { _all: number } }> = [];

    try {
      const rows = await db.$queryRaw<Array<{ yoshGuruhi: string; count: number }>>`
        SELECT "yoshGuruhi", COUNT(*)::int AS count
        FROM "Royxat"
        GROUP BY "yoshGuruhi"
      `;
      yoshStats = rows.map((row) => ({
        yoshGuruhi: row.yoshGuruhi,
        _count: { _all: Number(row.count) },
      }));
    } catch {
      console.warn("[admin-page] unable to load yosh summary");
    }

    try {
      const rows = await db.$queryRaw<Array<{ yonalish: string; count: number }>>`
        SELECT "yonalish", COUNT(*)::int AS count
        FROM "Royxat"
        GROUP BY "yonalish"
      `;
      yonalishStats = rows.map((row) => ({
        yonalish: row.yonalish,
        _count: { _all: Number(row.count) },
      }));
    } catch {
      console.warn("[admin-page] unable to load yonalish summary");
    }

    const nextTotalPages = Math.max(1, Math.ceil(dbFilteredCount / PAGE_SIZE));
    const nextCurrentPage = Math.min(requestedPage, nextTotalPages);
    const skip = (nextCurrentPage - 1) * PAGE_SIZE;

    let dbRoyxatlar: Array<(typeof royxatlar)[number]> = [];
    try {
      dbRoyxatlar = await db.royxat.findMany({
        where: activeWhere,
        orderBy,
        take: PAGE_SIZE,
        skip,
      });
    } catch {
      return null;
    }

    return {
      dbFilteredCount,
      dbTotal,
      nextCurrentPage,
      nextTotalPages,
      holatStats,
      yoshStats,
      yonalishStats,
      dbRoyxatlar,
    };
  };

  try {
    const data = await loadDashboardData(where);

    if (!data) {
      throw new Error("dashboard query failed");
    }

    filteredCount = data.dbFilteredCount;
    totalCount = data.dbTotal;
    currentPage = data.nextCurrentPage;
    totalPages = data.nextTotalPages;

    royxatlar = data.dbRoyxatlar.map((r: (typeof royxatlar)[number]) => ({
      ...r,
      yoshGuruhi: r.yoshGuruhi as string,
      holat: r.holat as "KUTILMOQDA" | "TASDIQLANDI" | "RAD_ETILDI",
    }));
    holatMap = Object.fromEntries(
      data.holatStats.map((s: { holat: string; _count: { _all: number } }) => [s.holat, s._count._all]),
    );
    yoshMap = Object.fromEntries(
      data.yoshStats.map((s: { yoshGuruhi: string; _count: { _all: number } }) => [s.yoshGuruhi, s._count._all]),
    );
    yonalishMap = Object.fromEntries(
      data.yonalishStats.map((s: { yonalish: string; _count: { _all: number } }) => [s.yonalish, s._count._all]),
    );
  } catch {
    console.warn("[admin-page] failed to load dashboard data; rendered fallback state");
  }

  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex-1" />
          <ExportButton
            filters={{
              ...(holat ? { holat } : {}),
              ...(yoshGuruhi ? { yoshGuruhi } : {}),
              ...(yonalish ? { yonalish } : {}),
              ...(utmType ? { utmType } : {}),
              ...(smsStatus ? { smsStatus } : {}),
              ...(searchQuery ? { q: searchQuery } : {}),
              ...(sortBy ? { sortBy } : {}),
              ...(sortDir ? { sortDir } : {}),
            }}
          />
        </div>

        <AdminFilters
          holat={holat}
          yoshGuruhi={yoshGuruhi}
          yonalish={yonalish}
          utmType={utmType}
          smsStatus={smsStatus}
          query={searchQuery}
          sortBy={sortBy}
          sortDir={sortDir}
          yoshOptions={Object.entries(YOSH_GURUH_LABELS) as [string, string][]}
          yonalishOptions={Object.entries(YONALISH_LABELS) as [string, string][]}
        />
      </div>

      <AdminDashboardClient
        key={`${currentPage}:${holat ?? "all"}:${yoshGuruhi ?? "all"}:${yonalish ?? "all"}:${utmType ?? "all"}:${smsStatus ?? "all"}:${searchQuery}:${holatMap.KUTILMOQDA ?? 0}:${holatMap.TASDIQLANDI ?? 0}:${holatMap.RAD_ETILDI ?? 0}`}
        initialRows={royxatlar.map((r) => ({
          ...r,
          createdAt: r.createdAt.toISOString(),
          smsSentAt: r.smsSentAt ? r.smsSentAt.toISOString() : null,
          resultUpdatedAt: r.resultUpdatedAt ? r.resultUpdatedAt.toISOString() : null,
        }))}
        filteredCount={filteredCount}
        currentPage={currentPage}
        pageSize={PAGE_SIZE}
        totalPages={totalPages}
        queryState={{
          holat,
          yoshGuruhi,
          yonalish,
          utmType,
          smsStatus,
          q: searchQuery || undefined,
          sortBy,
          sortDir,
        }}
        statusCounts={{
          total: totalCount,
          KUTILMOQDA: holatMap.KUTILMOQDA ?? 0,
          TASDIQLANDI: holatMap.TASDIQLANDI ?? 0,
          RAD_ETILDI: holatMap.RAD_ETILDI ?? 0,
        }}
        yoshCounts={yoshMap}
        yonalishCounts={yonalishMap}
      />
    </div>
  );
}
