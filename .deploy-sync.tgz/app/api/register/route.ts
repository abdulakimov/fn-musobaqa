import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { fullRegistrationSchema } from "@/lib/validations";
import { ZodError } from "zod";
import {
  submitRegistrationAndWait,
  type RegisterQueueData,
} from "@/lib/register-queue";
import {
  createRegistrationWithId,
  DuplicatePhoneError,
  RegistrationClosedError,
  LimitReachedError,
} from "@/lib/participant-id";
import { getRequestIdFromHeaders, logApiError } from "@/lib/api-log";
import { getVisitScheduleForParticipantId } from "@/lib/visit-schedule";
import { getCompetitionRules } from "@/lib/competition";
import { parseUtmCookie, toUtmMeta, UTM_COOKIE_NAME } from "@/lib/utm";
import { enqueueRegistrationSms } from "@/lib/sms-queue";

function getLimitReachedError(code: string | undefined) {
  if (code === "LIMIT_REACHED_TYPING") {
    return {
      error: "Typing yo'nalishi uchun ro'yxatdan o'tish yakunlandi. Barcha o'rinlar to'ldi.",
      code,
    };
  }
  if (code === "LIMIT_REACHED_MATH_9_11") {
    return {
      error: "Matematika 9-11 yosh toifasi uchun ro'yxatdan o'tish yakunlandi. Barcha o'rinlar to'ldi.",
      code,
    };
  }
  if (code === "LIMIT_REACHED_MATH_12_14") {
    return {
      error: "Matematika 12-14 yosh toifasi uchun ro'yxatdan o'tish yakunlandi. Barcha o'rinlar to'ldi.",
      code,
    };
  }
  return null;
}

export async function POST(req: NextRequest) {
  const requestId = getRequestIdFromHeaders(req.headers);
  try {
    const body = await req.json();
    const data = fullRegistrationSchema.parse(body);
    const queueEnabled = Boolean(process.env.REDIS_URL) && process.env.REGISTER_QUEUE_ENABLED !== "0";
    const utmFromCookie = parseUtmCookie(req.cookies.get(UTM_COOKIE_NAME)?.value);
    const utmMeta = toUtmMeta(utmFromCookie);
    const registerData: RegisterQueueData = {
      ...data,
      ...utmMeta,
    };

    const result = queueEnabled
      ? await submitRegistrationAndWait(registerData)
      : {
          ok: true as const,
          data: await createRegistrationWithId(db, registerData),
        };
    if (!result.ok) {
      if (result.code === "DUPLICATE_PHONE") {
        return NextResponse.json(
          { error: "Bu telefon raqam allaqachon ro'yxatdan o'tgan" },
          { status: 409, headers: { "x-request-id": requestId } }
        );
      }
      if (result.code === "REGISTRATION_CLOSED") {
        return NextResponse.json(
          {
            error: "Ro'yxatdan o'tish 2026-yil 16-aprel, 23:59 (Asia/Tashkent) da yopilgan",
            code: "REGISTRATION_CLOSED",
          },
          { status: 403, headers: { "x-request-id": requestId } }
        );
      }
      const limitReachedError = getLimitReachedError(result.code);
      if (limitReachedError) {
        return NextResponse.json(limitReachedError, {
          status: 403,
          headers: { "x-request-id": requestId },
        });
      }
      return NextResponse.json(
        { error: result.message ?? "Server xatosi yuz berdi" },
        { status: 500, headers: { "x-request-id": requestId } }
      );
    }

    if (!queueEnabled) {
      try {
        await enqueueRegistrationSms({
          registrationId: result.data.id,
          phone: registerData.telefon,
          participantId: result.data.participantId ?? "",
          ism: registerData.ism,
          familiya: registerData.familiya,
          otasiningIsmi: registerData.otasiningIsmi,
        });
      } catch (smsQueueError) {
        await db.royxat.update({
          where: { id: result.data.id },
          data: {
            smsStatus: "FAILED",
            smsError: (smsQueueError instanceof Error ? smsQueueError.message : "SMS queue error").slice(0, 300),
          },
        });
      }
    }

    const visit = getVisitScheduleForParticipantId(result.data.participantId ?? "");
    const rules = getCompetitionRules();
    return NextResponse.json(
      {
        success: true,
        id: result.data.id,
        participantId: result.data.participantId,
        visit,
        warning: "Belgilangan vaqtda kelmasangiz, qayta qo'shish imkoni bo'lmaydi.",
        registrationDeadline: rules.registrationDeadlineIso,
      },
      { status: 201, headers: { "x-request-id": requestId } }
    );
  } catch (error) {
    if (error instanceof DuplicatePhoneError) {
      return NextResponse.json(
        { error: "Bu telefon raqam allaqachon ro'yxatdan o'tgan" },
        { status: 409, headers: { "x-request-id": requestId } }
      );
    }
    if (error instanceof RegistrationClosedError) {
      return NextResponse.json(
        {
          error: "Ro'yxatdan o'tish 2026-yil 16-aprel, 23:59 (Asia/Tashkent) da yopilgan",
          code: "REGISTRATION_CLOSED",
        },
        { status: 403, headers: { "x-request-id": requestId } }
      );
    }
    if (error instanceof LimitReachedError) {
      const payload = getLimitReachedError(error.code);
      return NextResponse.json(
        payload ?? { error: "Ro'yxatdan o'tish yakunlangan", code: error.code },
        { status: 403, headers: { "x-request-id": requestId } }
      );
    }
    if (error instanceof ZodError) {
      return NextResponse.json({ errors: error.flatten() }, { status: 422, headers: { "x-request-id": requestId } });
    }
    logApiError("register", requestId, error);
    return NextResponse.json({ error: "Server xatosi yuz berdi" }, { status: 500, headers: { "x-request-id": requestId } });
  }
}
