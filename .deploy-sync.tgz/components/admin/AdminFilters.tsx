"use client";

import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Holat = "KUTILMOQDA" | "TASDIQLANDI" | "RAD_ETILDI";
type UtmType = "MAKTAB" | "BANNER" | "ORGANIK";
type SmsStatus = "PENDING" | "SENT" | "FAILED";

const ALL = "__ALL__";

const HOLAT_OPTIONS: Array<{ value: Holat; label: string }> = [
  { value: "KUTILMOQDA", label: "Kutilmoqda" },
  { value: "TASDIQLANDI", label: "Tasdiqlandi" },
  { value: "RAD_ETILDI", label: "Rad etildi" },
];

const UTM_OPTIONS: Array<{ value: UtmType; label: string }> = [
  { value: "MAKTAB", label: "Maktab" },
  { value: "BANNER", label: "Banner" },
  { value: "ORGANIK", label: "Organik" },
];

const SMS_STATUS_OPTIONS: Array<{ value: SmsStatus; label: string }> = [
  { value: "SENT", label: "Yuborildi" },
  { value: "FAILED", label: "Xato" },
  { value: "PENDING", label: "Kutilmoqda" },
];

const SORT_BY_OPTIONS = [
  { value: "createdAt", label: "Sana" },
  { value: "resultScore", label: "Natija ball" },
  { value: "resultUpdatedAt", label: "Natija yangilangan" },
  { value: "resultStatus", label: "Natija status" },
] as const;

const SORT_DIR_OPTIONS = [
  { value: "desc", label: "Kamayish bo'yicha" },
  { value: "asc", label: "O'sish bo'yicha" },
] as const;

interface AdminFiltersProps {
  holat?: Holat;
  yoshGuruhi?: string;
  yonalish?: string;
  utmType?: UtmType;
  smsStatus?: SmsStatus;
  query?: string;
  sortBy?: string;
  sortDir?: string;
  yoshOptions: [string, string][];
  yonalishOptions: [string, string][];
}

export function AdminFilters({
  holat,
  yoshGuruhi,
  yonalish,
  utmType,
  smsStatus,
  query,
  sortBy,
  sortDir,
  yoshOptions,
  yonalishOptions,
}: AdminFiltersProps) {
  const [search, setSearch] = useState(query ?? "");
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [, startTransition] = useTransition();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const currentQuery = searchParams.get("q") ?? "";

  const selectedHolatLabel = HOLAT_OPTIONS.find((item) => item.value === holat)?.label ?? "Barcha statuslar";
  const selectedYoshLabel = yoshOptions.find(([value]) => value === yoshGuruhi)?.[1] ?? "Barcha yoshlar";
  const selectedYonalishLabel = yonalishOptions.find(([value]) => value === yonalish)?.[1] ?? "Barcha yo'nalishlar";
  const selectedUtmLabel = UTM_OPTIONS.find((item) => item.value === utmType)?.label ?? "Barcha UTM";
  const selectedSmsLabel = SMS_STATUS_OPTIONS.find((item) => item.value === smsStatus)?.label ?? "Barcha SMS";
  const selectedSortByLabel = SORT_BY_OPTIONS.find((item) => item.value === (sortBy ?? "createdAt"))?.label ?? "Sana";
  const selectedSortDirLabel = SORT_DIR_OPTIONS.find((item) => item.value === (sortDir ?? "desc"))?.label ?? "Kamayish bo'yicha";

  const normalizeSelectValue = (value: string | null) => (value && value !== ALL ? value : undefined);

  const HOLAT_TRIGGER_STYLES: Record<string, string> = {
    KUTILMOQDA: "border-amber-300/80 bg-amber-50/40 text-amber-800",
    TASDIQLANDI: "border-emerald-300/80 bg-emerald-50/40 text-emerald-800",
    RAD_ETILDI: "border-rose-300/80 bg-rose-50/40 text-rose-800",
  };
  const YOSH_TRIGGER_STYLES: Record<string, string> = {
    YOSH_9_11: "border-indigo-300/80 bg-indigo-50/40 text-indigo-800",
    YOSH_12_14: "border-fuchsia-300/80 bg-fuchsia-50/40 text-fuchsia-800",
    YOSH_9_14: "border-teal-300/80 bg-teal-50/40 text-teal-800",
  };
  const YONALISH_TRIGGER_STYLES: Record<string, string> = {
    MATEMATIKA: "border-violet-300/80 bg-violet-50/40 text-violet-800",
    TYPING: "border-sky-300/80 bg-sky-50/40 text-sky-800",
  };
  const UTM_TRIGGER_STYLES: Record<string, string> = {
    MAKTAB: "border-emerald-300/80 bg-emerald-50/40 text-emerald-800",
    BANNER: "border-orange-300/80 bg-orange-50/40 text-orange-800",
    ORGANIK: "border-slate-300/80 bg-slate-50/40 text-slate-800",
  };
  const SMS_TRIGGER_STYLES: Record<string, string> = {
    SENT: "border-emerald-300/80 bg-emerald-50/40 text-emerald-800",
    FAILED: "border-rose-300/80 bg-rose-50/40 text-rose-800",
    PENDING: "border-slate-300/80 bg-slate-50/40 text-slate-800",
  };

  const replaceWith = useCallback(
    (
      updates: Partial<
      Record<"holat" | "yoshGuruhi" | "yonalish" | "utmType" | "smsStatus" | "q" | "sortBy" | "sortDir", string | undefined>
      >,
    ) => {
      const params = new URLSearchParams(searchParams.toString());
      const shouldResetPage =
        "holat" in updates ||
        "yoshGuruhi" in updates ||
        "yonalish" in updates ||
        "utmType" in updates ||
        "smsStatus" in updates ||
        "q" in updates ||
        "sortBy" in updates ||
        "sortDir" in updates;
      (Object.entries(updates) as Array<[string, string | undefined]>).forEach(([key, value]) => {
        if (!value || !value.trim()) {
          params.delete(key);
          return;
        }
        params.set(key, value);
      });
      if (shouldResetPage) {
        params.delete("page");
      }

      const nextQuery = params.toString();
      startTransition(() => {
        router.replace(nextQuery ? `${pathname}?${nextQuery}` : pathname, { scroll: false });
      });
    },
    [pathname, router, searchParams],
  );

  useEffect(() => {
    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, []);

  const onSearchChange = (value: string) => {
    setSearch(value);
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }
    debounceRef.current = setTimeout(() => {
      replaceWith({ q: value });
    }, 250);
  };

  const isFiltered = Boolean(
    holat ||
      yoshGuruhi ||
      yonalish ||
      utmType ||
      smsStatus ||
      currentQuery ||
      (sortBy && sortBy !== "createdAt") ||
      (sortDir && sortDir !== "desc"),
  );

  return (
    <div className="space-y-2">
      <Input
        type="search"
        value={search}
        onChange={(e) => onSearchChange(e.target.value)}
        placeholder="Qidirish: ism, familiya, participant ID"
        className="h-9 w-full rounded-xl"
      />

      <div className="grid grid-cols-1 gap-2 md:grid-cols-8">
        <Select value={holat ?? ALL} onValueChange={(value) => replaceWith({ holat: normalizeSelectValue(value) })}>
          <SelectTrigger className={`h-9 rounded-xl ${holat ? (HOLAT_TRIGGER_STYLES[holat] ?? "") : ""}`}>
            <SelectValue placeholder="Status">{selectedHolatLabel}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>Barcha statuslar</SelectItem>
            {HOLAT_OPTIONS.map((item) => (
              <SelectItem key={item.value} value={item.value}>
                {item.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={yoshGuruhi ?? ALL} onValueChange={(value) => replaceWith({ yoshGuruhi: normalizeSelectValue(value) })}>
          <SelectTrigger className={`h-9 rounded-xl ${yoshGuruhi ? (YOSH_TRIGGER_STYLES[yoshGuruhi] ?? "") : ""}`}>
            <SelectValue placeholder="Yosh toifasi">{selectedYoshLabel}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>Barcha yoshlar</SelectItem>
            {yoshOptions.map(([value, label]) => (
              <SelectItem key={value} value={value}>
                {label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={yonalish ?? ALL} onValueChange={(value) => replaceWith({ yonalish: normalizeSelectValue(value) })}>
          <SelectTrigger className={`h-9 rounded-xl ${yonalish ? (YONALISH_TRIGGER_STYLES[yonalish] ?? "") : ""}`}>
            <SelectValue placeholder="Yo'nalish">{selectedYonalishLabel}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>Barcha yo&apos;nalishlar</SelectItem>
            {yonalishOptions.map(([value, label]) => (
              <SelectItem key={value} value={value}>
                {label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={utmType ?? ALL} onValueChange={(value) => replaceWith({ utmType: normalizeSelectValue(value) })}>
          <SelectTrigger className={`h-9 rounded-xl ${utmType ? (UTM_TRIGGER_STYLES[utmType] ?? "") : ""}`}>
            <SelectValue placeholder="UTM">{selectedUtmLabel}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>Barcha UTM</SelectItem>
            {UTM_OPTIONS.map((item) => (
              <SelectItem key={item.value} value={item.value}>
                {item.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={smsStatus ?? ALL} onValueChange={(value) => replaceWith({ smsStatus: normalizeSelectValue(value) })}>
          <SelectTrigger className={`h-9 rounded-xl ${smsStatus ? (SMS_TRIGGER_STYLES[smsStatus] ?? "") : ""}`}>
            <SelectValue placeholder="SMS">{selectedSmsLabel}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>Barcha SMS</SelectItem>
            {SMS_STATUS_OPTIONS.map((item) => (
              <SelectItem key={item.value} value={item.value}>
                {item.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={sortBy ?? "createdAt"} onValueChange={(value) => replaceWith({ sortBy: value ?? undefined })}>
          <SelectTrigger className="h-9 rounded-xl">
            <SelectValue placeholder="Tartiblash turi">{selectedSortByLabel}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            {SORT_BY_OPTIONS.map((item) => (
              <SelectItem key={item.value} value={item.value}>
                {item.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={sortDir ?? "desc"} onValueChange={(value) => replaceWith({ sortDir: value ?? undefined })}>
          <SelectTrigger className="h-9 rounded-xl">
            <SelectValue placeholder="Tartiblash yo'nalishi">{selectedSortDirLabel}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            {SORT_DIR_OPTIONS.map((item) => (
              <SelectItem key={item.value} value={item.value}>
                {item.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {isFiltered ? (
          <Link
            href="/admin"
            className="inline-flex h-9 items-center justify-center rounded-xl border border-border px-3 text-sm text-muted-foreground transition-colors hover:border-red-300 hover:text-red-400"
          >
            Filtrni o&apos;chirish
          </Link>
        ) : (
          <div />
        )}
      </div>
    </div>
  );
}
