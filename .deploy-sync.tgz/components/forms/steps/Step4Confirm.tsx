"use client";

import { useCallback, useState } from "react";
import { appToast as toast } from "@/lib/toast";
import {
  type FullRegistrationData,
  YONALISH_LABELS,
  YOSH_GURUH_LABELS,
} from "@/lib/validations";
import { Button } from "@/components/ui/button";
import {
  ArrowLeftIcon,
  CheckCircle2Icon,
  Loader2Icon,
} from "lucide-react";
import type { RegisterFormContent } from "@/lib/site-content";
import { STATIC_SITE_SETTINGS } from "@/lib/site-content";
import { VisitInfoDialog } from "@/components/forms/VisitInfoDialog";

interface Props {
  data: FullRegistrationData;
  onBack: () => void;
  content?: RegisterFormContent;
}

function getFirstFieldError(errors: unknown) {
  if (!errors || typeof errors !== "object") return null;
  const fieldErrors = (errors as { fieldErrors?: Record<string, unknown> }).fieldErrors;
  if (!fieldErrors || typeof fieldErrors !== "object") return null;

  for (const value of Object.values(fieldErrors)) {
    if (Array.isArray(value)) {
      const firstMessage = value.find((item) => typeof item === "string");
      if (typeof firstMessage === "string" && firstMessage.trim()) {
        return firstMessage;
      }
    }
  }

  return null;
}

export function Step4Confirm({ data, onBack, content }: Props) {
  const common = content?.common;
  const step4 = content?.step4;
  const telegramUrl = STATIC_SITE_SETTINGS.telegram ?? "https://t.me/robbituz";
  const fieldLabels: Array<{
    key: keyof FullRegistrationData;
    label: string;
    format?: (v: unknown) => string;
  }> = [
    { key: "ism", label: step4?.firstNameLabel ?? "Ism" },
    { key: "familiya", label: step4?.lastNameLabel ?? "Familiya" },
    { key: "otasiningIsmi", label: step4?.middleNameLabel ?? "Otasining ismi" },
    { key: "telefon", label: step4?.phoneLabel ?? "Telefon" },
    {
      key: "yonalish",
      label: step4?.directionLabel ?? "Yo'nalish",
      format: (v) => YONALISH_LABELS[v as string] ?? String(v),
    },
    {
      key: "yoshGuruhi",
      label: step4?.ageGroupLabel ?? "Yosh guruhi",
      format: (v) => YOSH_GURUH_LABELS[v as string] ?? String(v),
    },
  ];

  const [loading, setLoading] = useState(false);
  const [visitInfo, setVisitInfo] = useState<{
    participantId: string;
    visitText: string;
    directionLabel: string;
    warning: string;
  } | null>(null);

  const handleVisitDone = useCallback(() => {
    if (!visitInfo) return;
    toast.success("Ro'yxatdan o'tdingiz");
    setVisitInfo(null);
    window.location.assign(telegramUrl);
  }, [telegramUrl, visitInfo]);

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const json = await res.json();

      if (res.ok) {
        const participantId = String(json.participantId ?? "").toUpperCase();
        if (!participantId) {
          toast.error("ID generatsiyasida xatolik yuz berdi");
          return;
        }
        setVisitInfo({
          participantId,
          visitText: String(json?.visit?.displayText ?? "Tashrif vaqti aniqlanmadi"),
          directionLabel: YONALISH_LABELS[data.yonalish] ?? String(data.yonalish),
          warning: String(json?.warning ?? "Belgilangan vaqtda kelmasangiz, qayta qo'shish imkoni bo'lmaydi."),
        });
      } else if (res.status === 409) {
        toast.error("Bu telefon raqam allaqachon ro'yxatdan o'tgan");
      } else if (res.status === 403 && json?.code === "REGISTRATION_CLOSED") {
        toast.error(json?.error ?? "Ro'yxatdan o'tish yopilgan");
      } else if (
        res.status === 403 &&
        (json?.code === "LIMIT_REACHED_TYPING" ||
          json?.code === "LIMIT_REACHED_MATH_9_11" ||
          json?.code === "LIMIT_REACHED_MATH_12_14")
      ) {
        toast.error(json?.error ?? "Ushbu yo'nalish/yosh toifasi uchun ro'yxatdan o'tish yakunlangan.");
      } else if (res.status === 422) {
        const firstFieldError = getFirstFieldError(json?.errors);
        toast.error(firstFieldError ?? json?.error ?? "Ma'lumotlarda xatolik bor. Iltimos tekshirib qayta yuboring.");
      } else {
        toast.error(json.error ?? "Xatolik yuz berdi, qayta urinib ko'ring");
      }
    } catch {
      toast.error("Tarmoq xatosi. Internet aloqangizni tekshiring");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="space-y-6">
        <div>
          <h3 className="mb-1 font-display text-lg font-semibold">
            {step4?.title ?? "Ma'lumotlarni tasdiqlang"}
          </h3>
          <p className="text-sm text-muted-foreground">
            {step4?.subtitle ?? "Yuborishdan oldin ma'lumotlarni tekshiring"}
          </p>
        </div>

        <div className="divide-y divide-border rounded-xl border border-border bg-muted/30">
          {fieldLabels
            .filter((f) => data[f.key] !== undefined && data[f.key] !== "" && data[f.key] !== null)
            .map(({ key, label, format }) => (
              <div key={key} className="flex items-center justify-between px-4 py-3 text-sm">
                <span className="text-muted-foreground">{label}</span>
                <span className="text-right font-medium">{format ? format(data[key]) : String(data[key])}</span>
              </div>
            ))}
        </div>

        <div className="flex gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={onBack}
            className="h-12 flex-1 gap-2 rounded-full"
            disabled={loading}
          >
            <ArrowLeftIcon className="h-4 w-4" />
            {common?.backText ?? content?.backText ?? "Orqaga"}
          </Button>
          <Button
            type="button"
            onClick={handleSubmit}
            disabled={loading}
            className="glow-blue h-12 flex-1 gap-2 rounded-full bg-electric-blue text-base font-semibold text-background hover:bg-electric-blue/90"
          >
            {loading ? <Loader2Icon className="h-4 w-4 animate-spin" /> : <CheckCircle2Icon className="h-4 w-4" />}
            {loading
              ? (common?.submitLoadingText ?? "Yuborilmoqda...")
              : (common?.submitText ?? content?.submitText ?? "Yuborish")}
          </Button>
        </div>
      </div>
      {visitInfo ? (
        <VisitInfoDialog
          participantId={visitInfo.participantId}
          visitText={visitInfo.visitText}
          directionLabel={visitInfo.directionLabel}
          warning={visitInfo.warning}
          address={STATIC_SITE_SETTINGS.address ?? "Farg'ona viloyati, Fag'ona shahri, Najot Ta'lim binosi"}
          mapUrl={STATIC_SITE_SETTINGS.mapUrl ?? "https://yandex.uz/maps/-/CPfhBImd"}
          telegramUrl={telegramUrl}
          onDone={handleVisitDone}
        />
      ) : null}
    </>
  );
}

