import { test, expect } from "@playwright/test";

test("admin csv export matches active filters dataset", async ({ page }) => {
  await page.goto("/register");

  const stamp = Date.now().toString().slice(-5);
  const marker = stamp
    .split("")
    .map((digit) => String.fromCharCode(65 + Number(digit)))
    .join("");
  const createPayload = (suffix: string, yonalish: "MATEMATIKA" | "TYPING") => ({
    ism: `Audit${marker}`,
    familiya: "CsvExport",
    otasiningIsmi: "Checker",
    telefon: `+99891${stamp}${suffix}`,
    yonalish,
    yoshGuruhi: yonalish === "TYPING" ? "YOSH_9_14" : "YOSH_9_11",
  });

  const seedResult = await page.evaluate(async ({ payloadA, payloadB }) => {
    const send = async (payload: unknown) => {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      return { status: res.status, json: await res.json() };
    };
    return {
      typing: await send(payloadA),
      math: await send(payloadB),
    };
  }, { payloadA: createPayload("11", "TYPING"), payloadB: createPayload("22", "MATEMATIKA") });

  expect(seedResult.typing.status).toBe(201);
  expect(seedResult.math.status).toBe(201);

  await page.goto("/admin/login");
  await page.locator('input[name="username"]').fill(process.env.ADMIN_USERNAME ?? "musobaqa");
  await page.locator('input[name="password"]').fill(process.env.ADMIN_PASSWORD ?? "robbitadmin");
  await page.getByRole("button", { name: "Kirish" }).click();
  await expect(page).toHaveURL(/\/admin$/);
  const cookies = await page.context().cookies();
  expect(cookies.some((item) => item.name === "admin_session")).toBeTruthy();

  const audit = await page.evaluate(async (query) => {
    const params = new URLSearchParams({
      yonalish: "TYPING",
      q: query,
    });

    const [jsonRes, csvRes] = await Promise.all([
      fetch(`/api/admin/registrations?${params.toString()}`, { credentials: "include" }),
      fetch(`/api/admin/registrations?format=csv&${params.toString()}`, { credentials: "include" }),
    ]);

    const json = await jsonRes.json();
    const csv = await csvRes.text();
    const lines = csv.trim().split(/\r?\n/);

    return {
      jsonStatus: jsonRes.status,
      csvStatus: csvRes.status,
      total: Number(json.total ?? 0),
      linesCount: lines.length,
      csv,
    };
  }, `Audit${marker}`);

  expect(audit.jsonStatus).toBe(200);
  expect(audit.csvStatus).toBe(200);
  expect(audit.total).toBeGreaterThan(0);
  expect(audit.linesCount).toBe(audit.total + 1);
  expect(audit.csv).toContain(`Audit${marker}`);
});
