import { test, expect } from "@playwright/test";

test("registration success shows visit popup and continues via button", async ({ page }) => {
  const browserErrors: string[] = [];
  const consoleErrors: string[] = [];
  page.on("pageerror", (error) => browserErrors.push(error.message));
  page.on("console", (message) => {
    if (message.type() === "error") {
      consoleErrors.push(message.text());
    }
  });

  await page.addInitScript(() => {
    Object.defineProperty(navigator, "clipboard", {
      configurable: true,
      value: {
        writeText: async () => {},
      },
    });
  });

  await page.route("**/api/register", async (route) => {
    await route.fulfill({
      status: 201,
      contentType: "application/json",
      body: JSON.stringify({
        success: true,
        id: "mock-id-popup",
        participantId: "A1111",
        visit: {
          scheduledAt: "2026-04-19T09:00:00+05:00",
          displayText: "19-aprel, 09:00",
        },
        warning: "Belgilangan vaqtda kelmasangiz, qayta qo'shish imkoni bo'lmaydi.",
      }),
    });
  });

  await page.goto("/register");
  await page.getByPlaceholder("Abdulloh").fill("Ali");
  await page.getByPlaceholder("Karimov").fill("Karimov");
  await page.getByPlaceholder("Bahodir o'g'li").fill("Vali o'g'li");
  await page.getByPlaceholder("+998 91-234-56-73").fill("901112233");
  await page.getByRole("combobox").nth(0).click();
  await page.getByRole("option", { name: "Typing" }).click();
  await page.getByRole("button", { name: /davom etish/i }).click();
  await page.getByRole("button", { name: /yuborish/i }).click();

  await expect(page.getByText(/tashrif vaqti tasdiqlandi/i)).toBeVisible();
  await expect(page.getByText(/musobaqa bileti/i).first()).toBeVisible();
  await expect(page.getByRole("button", { name: /biletni yuklab olish/i })).toBeVisible();
  await expect(page.getByRole("button", { name: /id ni nusxalash/i })).toBeVisible();
  await page.getByRole("button", { name: /id ni nusxalash/i }).click();
  await expect(page.getByText(/id nusxalandi/i)).toBeVisible();
  await page.screenshot({ path: "test-results/popup-open.png", fullPage: true });

  await page.keyboard.press("Escape");
  await expect(page.getByText(/tashrif vaqti tasdiqlandi/i)).toBeVisible();

  await expect(page.getByRole("button", { name: /davom etish/i })).toBeVisible();
  await page.getByRole("button", { name: /davom etish/i }).click();

  await expect(page).toHaveURL(/https:\/\/t\.me\/robbituz/);
  expect(browserErrors.join("\n")).not.toContain("Cannot update a component");
  expect(consoleErrors.join("\n")).not.toContain("Cannot update a component");
});
